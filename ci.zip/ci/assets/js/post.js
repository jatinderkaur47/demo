$(document).ready(function() {
       getPosts(1);
});
function getPosts(page){ 
	$.ajax({
        url: site_url+'demo/getPosts',
        type: 'POST',
		data: {'page':page},
        success: function(res) {
			$('#response').slideToggle(100,function(){
				  $('#response').html(res);
				  $('#response').show();
			});
         
        }
    });
}
function getcomments(comment_id){ 
    var url= site_url+'demo/getComments';
    $.ajax({
        url: url,
        type: 'POST',
		data: {'type':'comment','commentId':comment_id},
        success: function(res) {
			$('#comments_'+comment_id).slideToggle(100,function(){
				$('#comments_'+comment_id).html(res);
			});
			
        }
    });
}
function deleteComment(comment_id){
	var agree = confirm("Are you sure you want to delete this Comment?");
	if(agree == true){
		var url= site_url+'demo/deletePostComments';
		$.ajax({
			url: url,
			type: 'POST',
			data: {'type':'comment','commentId':comment_id},
			success: function(response) {
				if(response.status=='success'){
					alert(response.message);
				}else{
					alert('something went wrong.');
				}
			}
		});
	}
	else{
		return false;
	}
}

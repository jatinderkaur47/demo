<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Demo extends CI_Controller {
	private $apiUrl = "https://jsonplaceholder.typicode.com/";
	private $token = "";
    public function __construct(){
		try{
			parent::__construct();
			$userName = "test"; $password = "test@123";
			$userAuthenticate = $this->authenticateUser($userName,$password);
			if($userAuthenticate==false){
				throw new Exception("User is not valid");
			}
		}catch(Exception $e){
		    $info = array('status' => 'error', 'message' => $e->getMessage());
            echo $this->sendResponse(200, json_encode($info));
        }
	}
	public function request(){
	   $this->load->view('/demo/request');
	}
	public function getPosts(){ 
		try{
		    $post = $this->input->post();
			$page = $post['page'];
			
			$url = $this->apiUrl."posts?userId=".$this->token;
			$post = array('username'=>'test','password'=>'test');
			$response = $this->curlRequest($url,$post);
			$data = json_decode($response,true);
			
			##pagination##
			$rpp = 3;
			$page = !empty($page) ? $page : 1;			
			$rows = count($data);
			$totalpages = ceil($rows / $rpp);
			if($totalpages != 0) {
				$page = $page > $totalpages ? $totalpages : $page;
				$startrow = ($page - 1) * $rpp;
			}else{
				$startrow = 0;
			}
			$this->data['curpage'] = $page;
			$this->data['startpage'] = $page - 3 > 1 ? ($page - 3) : 1;
			$this->data['endpage'] = ($page + 3) <= $totalpages ? ($page + 3) : $totalpages;
			$this->data['totalpages'] = $totalpages;
			
			## I donot find any way to get data using pagination parameter from API 
			## so get full data on every hit and show with pagination 
			## we can avoid to get data on every call
			$finaldata = array();
			for($i = $startrow; $i < ($rpp+$startrow); $i++){
				if(array_key_exists($i,$data)){
					$finaldata[$i] = $data[$i];
				}
			}
			$this->data['response'] = $finaldata;
			
			$this->load->view('/demo/get_posts',$this->data);
		}catch(Exception $e){
		    $info = array('status' => 'error', 'message' => $e->getMessage());
            echo $this->sendResponse(200, json_encode($info));
        }
	}
	
	public function getComments(){
		try{			
		    $post = $this->input->post();
			$commentId = $post['commentId'];
			$url = $this->apiUrl."comments?postId=".$commentId;
			$post = array('username'=>'test','password'=>'test');
			$response = $this->curlRequest($url,$post);
			if(empty($response)){
				throw new Exception('Something went wrong');
			}
			$this->data['response'] = json_decode($response,true);
			$this->load->view('/demo/comments',$this->data);
		}catch(Exception $e){
		    $info = array('status' => 'error', 'message' => $e->getMessage());
            echo $this->sendResponse(200, json_encode($info));
        }
		
	}
	
	public function deletePostComments(){
		try{			
		    $post = $this->input->post();
			$method = $post['type'];
			$commentId = $post['commentId'];
			if(empty($commentId)){
				throw new Exception("There is no valid input.");
			}
			##  I don't find API to delete the Comment so I am giving the success method of deletion.
			//$url = $this->apiUrl."comments?postId=".$commentId;
			$response = array('status'=>'success','message'=>'comment has been deleted successsfully.');
			//$response = $this->curlRequest($url,$post);

			echo $this->sendResponse(200, json_encode($response));
		}catch(Exception $e){
		    $info = array('status' => 'error', 'message' => $e->getMessage());
            echo $this->sendResponse(200, json_encode($info));
        }
	}
	
	private function authenticateUser($userName,$password){
		# Right Now I am assuming user is authenicated the return the user_id as TokenId
        ## Once user is authenicated and token is geneated then we store the token against the user and pass it to all requests		
		$authenticateUser = true;
		$this->token = 1;
		if($authenticateUser==true){
			return $this->token;
		}else{
			return false;
		}
	}
    private function curlRequest($url = NULL, $post = NULL ,$method="GET"){
        if($url && $post){
            $timeout = 90;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            if($method=='POST'){
			  curl_setopt($ch, CURLOPT_POST, count($POST));
              curl_setopt($ch, CURLOPT_POSTFIELDS, urldecode(http_build_query($post)));
			}
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);            
            if($result === FALSE) {
                return false;
            }else{
               return $result;
            }
		}else{
			return false;
		}
	}
	private function sendResponse($status = 200, $body = '', $content_type = 'application/json; charset=UTF-8'){
        $status_header = 'HTTP/1.1 ' . $status . ' ' . $this->getStatusCodeMessage($status);
        header($status_header);
        header('Content-type: ' . $content_type);
		return $body; 
    }
    private function getStatusCodeMessage($status) {
        $codes = Array(
            200 => 'OK',
            500 => 'Internal Server Error',
            501 => 'Not Implemented',
            502 => 'Bad Gateway',
            503 => 'Service Unavailable',
            504 => 'Gateway Timeout',
            505 => 'HTTP Version Not Supported'
        );
        return (isset($codes[$status])) ? $codes[$status] : '';
    }
}

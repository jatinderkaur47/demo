<div class="table">
<table class="table">
<thead>
	<tr><th>Title</th><th>Body</th><th></th><th></th></tr>
</thead>
<tbody>
<?php  
foreach($response as $k =>$value){ ?>
	<tr>
		<td><?php echo $value['title']; ?></td>
		<td><?php echo $value['body']; ?><br /><span  style="display:none" id="comments_<?php echo $value['id']; ?>" ></span></td>
		<td><button type="button" class="btn btn-success" onclick="getcomments('<?php echo $value['id']; ?>')">Show comments</button></td>
		<td>
			
		</td>
	</tr>

<?php } ?>
</tbody>
</table>
</div>

<?php if(!empty($response)){ ?>
<div id="pagination" class="col-sm-6">
    <?php if ($curpage - 1 > 0): ?>
        <!-- previous page -->
        <a href="javascript: getPosts(<?php echo $curpage - 1; ?>);">
            &lt;&lt;</a>
    <?php endif; ?>
    <!-- page links -->
    <?php for ($i = $startpage; $i <= $endpage; $i++): ?>
        <?php if ($curpage == $i): ?>
            <a style="color:red;" class="active"  href="javascript: getPosts(<?php echo $i; ?>);"><?php echo $i; ?></a>
        <?php else: ?>
            <a href="javascript: getPosts(<?php echo $i; ?>);"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($curpage + 1 <= $totalpages): ?>
        <!-- next link -->
        <a href="javascript: getPosts(<?php echo $curpage + 1; ?>);">
            &gt;&gt;</a>
    <?php endif; ?>
</div>
<?php } ?>




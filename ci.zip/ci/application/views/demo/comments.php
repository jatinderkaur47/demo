
<div class="table table-striped">
<table class="table">
<thead>
	<tr><th>Name</th><th>Email</th><th>Body</th><th>Action</th></tr>
</thead>
<tbody>
<?php  
	if(!empty($response)){
		foreach($response as $k =>$value){ ?>
			<tr>
				<td><?php echo $value['name']; ?></td>
				<td><?php echo $value['email']; ?></td>
				<td><?php echo $value['body']; ?></td>
				<td><button type="button" class="btn btn-success" onclick="deleteComment('<?php echo $value['id']; ?>')">Delete</button></td>
			</tr>
	<?php }
} ?>
</tbody>
</table>
</div>



